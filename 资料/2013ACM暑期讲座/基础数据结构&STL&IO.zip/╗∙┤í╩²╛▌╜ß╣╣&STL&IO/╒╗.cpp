//声明
int stk[MAXN],top=0;
//插入
stk[top++]=1;
//选取
a=stk[--top];