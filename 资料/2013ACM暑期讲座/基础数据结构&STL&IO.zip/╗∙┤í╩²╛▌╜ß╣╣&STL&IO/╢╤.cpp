//声明
int a[MAXN],n=0;//n代表元素个数，堆的标号从1开始，a[2*i]为a[i]的左孩子，a[2*i+1]为a[i]的右孩子
void up(int a[],int i)
{
    int t=a[i]; 
	while(i>1&&t<a[i/2])
    {
        a[i]=a[i/2];
        i/=2;
    }
    a[i]=t;
}
void down(int a[],int i,int n)
{
    int t=a[i],u=i*2;
    while(u+1<=n)
    {
        u=a[u]<a[u+1]?u:u+1;
        if(t<=a[u])
            break;
        a[i]=a[u];
        i=u;
        u=i*2;
    }
    a[i]=t;
}
