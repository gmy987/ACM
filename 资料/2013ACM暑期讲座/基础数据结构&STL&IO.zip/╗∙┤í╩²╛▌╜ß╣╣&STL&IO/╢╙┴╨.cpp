/*************普通队列**************/
//声明
int ls[MAXN],front=0,rear=0;
//插入元素
ls[rear++]=1;
//取出元素
now=ls[front++];
//判空
front<rear

/*************循环队列**************/
//声明
int ls[MAXN],front=0,rear=0;
//插入元素
ls[rear++]=1;
if(rear==MAXN)rear=0;
//取出元素
now=ls[front++];
if(front==MAXN)front=0;
//判空
front!=rear