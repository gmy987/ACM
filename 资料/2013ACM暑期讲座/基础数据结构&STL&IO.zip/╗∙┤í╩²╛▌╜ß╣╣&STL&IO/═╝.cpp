/***************邻接矩阵*****************/
bool map[MAXN][MAXN];
如果i，j有无向边
map[i][j]=map[j][i]=true;
如果有i通向j的边
map[i][j]=true;




/*******************邻接表******************/
int head[MAXN],ne=0;//head[a]代表从a出发的第一条边的标号，如果没有，则为-1
					//ne为边的总数
					
struct Edge
{
	int to,//当前边通往的结点
		nxt;//下一个由起始点出发的边的标号
}edge[MAXE];
void add(int a,int b,int c)//添加a到b的边
{
	edge[ne].to=b;edge[ne].nxt=head[a];head[a]=ne++;
}

for(int i=head[a];i!=-1;i=edge[i].nxt)
{
..
}