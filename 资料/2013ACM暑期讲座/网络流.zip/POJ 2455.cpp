#pragma comment(linker, "/STACK:102400000,102400000")
#include<iostream>
#include<cstdio>
#include<memory.h>
#include<string>
#include<cmath>
#include<cctype>
#include<algorithm>
#include<queue>
#include<set>
#include<map>
#include<stack>
#include<vector>
#include<functional>
#define sqr(x) ((x)*(x))
#define ll long long
#define ii pair<int,int>
#define mp make_pair
#define ms(x,y) memset(x,y,sizeof(x))
#define rep(x,y,z) for (int x=y;x<z;x++)
#define drep(x,y,z) for (int x=y;x>=z;x--)
#define all(x) x.begin(),x.end()
#define X first
#define Y second
using namespace std;
const int size=210,mod=2012,inf=0x3f3f3f3f;
const ll llmod=4294967296ll,llinf=0x3f3f3f3f3f3f3f3fll;
const double pi=acos(-1.0),eps=1e-6;
int month[2][13]={0,31,28,31,30,31,30,31,31,30,31,30,31,
				  0,31,29,31,30,31,30,31,31,30,31,30,31};
int nex[2][8]={-1,0,1,0,-1,1,1,-1,0,1,0,-1,1,1,-1,-1};
template<class T> inline void inc(T &a,T b){a=(a+b)%mod;}
template<class T> inline T modu(T a){return (a%mod+mod)%mod;}
template<class T> inline void crl(T* l,T *r,int step){T tmp=*l;for (T* i=l;i<r;i+=step)*i=*(i+step);*(r-1)=tmp;}
template<class T> inline void crr(T* l,T *r,int step){T tmp=*(r-1);for (T* i=r-1;i>l;i-=step)*i=*(i-step);*l=tmp;}
bool inline dbeq(double a,double b){return fabs(a-b)<eps;}
template<class T> inline void cmin(T& a,T b){a=min(a,b);}
template<class T> inline void cmax(T& a,T b){a=max(a,b);}
/***********************************************************/
struct edge
{
	int a,b,next,f;
}e[size*size*8];//sizeӦ�ô��ڲ���ĵ���֮��
int cnt,v[size];
void init()
{
	cnt=0,memset(v,-1,sizeof(v));
}
void add (int a,int b,int f)//��ÿ������߽���
{
	e[cnt].a=a;
	e[cnt].b=b;
	e[cnt].f=f;
	e[cnt].next=v[a];
	v[a]=cnt++;
	e[cnt].b=a;
	e[cnt].a=b;
	e[cnt].f=0;
	e[cnt].next=v[b];
	v[b]=cnt++;
}
int dis[size],q[size];
int bfs(int s,int t)  
{  
    int i,x,a,tail=0,head=0;  
    memset(dis,0,sizeof(dis));  
    dis[s]=1;  
    q[tail++]=s;  
    while(head<tail)  
    {  
        x=q[head++];          
        for(i=v[x];i!=-1;i=e[i].next)  
            if(e[i].f&&dis[a=e[i].b]==0)  
            {  
                dis[a]=dis[x]+1;  
                if(a==t)  
                    return 1;  
                q[tail++]=a;  
            }  
    }  
    return 0;  
}  
int dfs(int s,int t,int limit)  
{  
    if(s==t)  
        return limit;  
    int i,a,tmp,cost=0;  
    for(i=v[s];i!=-1;i=e[i].next)  
        if(e[i].f&&dis[s]==dis[a=e[i].b]-1)  
        { 
            tmp=dfs(a,t,min(limit-cost,e[i].f));  
            if(tmp>0)  
            {  
                e[i].f-=tmp;  
                e[i^1].f+=tmp;  
                cost+=tmp;  
                if(limit==cost)  
                    break;  
            }  
            else dis[a]=-1;  
        }  
    return cost;  
}  
int Dinic(int s,int t)  
{  
    int ans=0;  
    while(bfs(s,t))  
        ans+=dfs(s,t,inf);  
    return ans;  
} 

struct 
{
	int a,b,c;
}eg[size*size*8];
int s,t,n,m,p;
bool solve (int mid)
{
	init();
	rep(i,0,m)
		if (eg[i].c<=mid)
			add(eg[i].a,eg[i].b,1),add(eg[i].b,eg[i].a,1);
	return Dinic(s,t)>=p;
}
int main ()
{
	char str[20];
	while(scanf("%d%d%d",&n,&m,&p)!=EOF)
	{
		int ma=0;
		s=1,t=n;
		rep(i,0,m)
			scanf("%d%d%d",&eg[i].a,&eg[i].b,&eg[i].c),cmax(ma,eg[i].c);
		int l=1,r=ma+1;
		while(l<r)
		{
			int mid=l+r>>1;
			if (!solve(mid))
				l=mid+1;
			else
				r=mid;
		}
		printf("%d\n",r);
	}
	return 0;
}