#pragma comment(linker, "/STACK:102400000,102400000")
#include<iostream>
#include<cstdio>
#include<memory.h>
#include<string>
#include<cmath>
#include<cctype>
#include<algorithm>
#include<queue>
#include<set>
#include<map>
#include<stack>
#include<vector>
#include<functional>
#define sqr(x) ((x)*(x))
#define ll long long
#define ii pair<int,int>
#define mp make_pair
#define ms(x,y) memset(x,y,sizeof(x))
#define rep(x,y,z) for (int x=y;x<z;x++)
#define drep(x,y,z) for (int x=y;x>=z;x--)
#define all(x) x.begin(),x.end()
#define X first
#define Y second
using namespace std;
const int size=210,esize=210*210,mod=1000000007,inf=0x3f3f3f3f;
const ll llmod=4294967296ll,llinf=0x3f3f3f3f3f3f3f3fll;
const double pi=acos(-1.0),eps=1e-7;
int month[2][13]={0,31,28,31,30,31,30,31,31,30,31,30,31,
                  0,31,29,31,30,31,30,31,31,30,31,30,31};
int nex[2][8]={-1,0,1,0,-1,1,1,-1,0,1,0,-1,1,1,-1,-1};
template<class T> inline void inc(T &a,T b){a=(a+b)%mod;}
template<class T> inline T modu(T a){return (a%mod+mod)%mod;}
template<class T> inline void crl(T* l,T *r,int step){T tmp=*l;for (T* i=l;i<r;i+=step)*i=*(i+step);*(r-1)=tmp;}
template<class T> inline void crr(T* l,T *r,int step){T tmp=*(r-1);for (T* i=r-1;i>l;i-=step)*i=*(i-step);*l=tmp;}
bool inline dbeq(double a,double b){return fabs(a-b)<eps;}
template<class T> inline void cmin(T& a,T b){a=min(a,b);}
template<class T> inline void cmax(T& a,T b){a=max(a,b);}
/***********************************************************/
struct node
{
	int a,b,f,c,next;
}e[esize*2];
int cnt,v[size];
void init()
{
	cnt=0,memset(v,-1,sizeof(v));
}
void add(int a,int b,int f,int c)//��ÿ�������
{
	e[cnt].a=a;
	e[cnt].b=b;
	e[cnt].f=f;
	e[cnt].c=c;
	e[cnt].next=v[a];
	v[a]=cnt++;
	e[cnt].a=b;
	e[cnt].b=a;
	e[cnt].f=0;
	e[cnt].c=-c;
	e[cnt].next=v[b];
	v[b]=cnt++;
}
int head,tail,dis[size],q[size],pre[size],mark[size],pos[size];
bool spfa (int s,int t)
{
	int i,a,b;
	memset(mark,0,sizeof(mark));
	memset(pre,-1,sizeof(pre));
	memset(dis,0x3f,sizeof(dis));
	head=tail=0;
	dis[s]=0;
	q[tail++]=s;
	while (head!=tail)
	{
		a=q[head++];
		if (head==size)
			head=0;
		mark[a]=0;
		for (i=v[a];i!=-1;i=e[i].next)
		{
			b=e[i].b;
			if (e[i].f>0&&dis[b]>dis[a]+e[i].c)
			{
				pre[b]=a;
				pos[b]=i;
				dis[b]=dis[a]+e[i].c;
				if (!mark[b])
				{
					mark[b]=1;
					q[tail++]=b;
					if (tail==size)
						tail=0;
				}
			}
		}
	}
	return pre[t]!=-1&&dis[t]<inf;
}
ii mcf (int s,int t)
{
	int flow=0,cost=0,mflow,i;
	while (spfa(s,t))
	{
		mflow=inf;
		for (i=t;i!=s;i=pre[i])
			mflow=min(mflow,e[pos[i]].f);
		for (i=t;i!=s;i=pre[i])
		{
			e[pos[i]].f-=mflow;
			e[pos[i]^1].f+=mflow;
		}
		flow+=mflow;
		cost+=dis[t]*mflow;
	}
	return mp(cost,flow);
}
int a,man[52][52],shop[52][52];
int main ()
{
	int n,m,k,s,t,a,ans;
	while(scanf("%d%d%d",&n,&m,&k),n&&m&&k)
	{
		rep(i,0,n)
			rep(j,0,k)
				scanf("%d",&man[i][j]);
		rep(i,0,m)
			rep(j,0,k)
				scanf("%d",&shop[i][j]);
		bool flag=1;
		int ans=0;
		rep(l,0,k)
		{
			int sum=0;
			init();
			s=n+m+1,t=n+m+2;
			rep(i,0,n)
				add(s,i,man[i][l],0),sum+=man[i][l];
			rep(i,0,m)
				add(i+n,t,shop[i][l],0);
			rep(i,0,n)
				rep(j,0,m)
					scanf("%d",&a),add(i,j+n,inf,a);
			ii tmp=mcf(s,t);
			ans+=tmp.first;
			if (tmp.second!=sum)
				flag=0;
		}
		if (flag)
			printf("%d\n",ans);
		else
			printf("-1\n");
	}
	return 0;
}