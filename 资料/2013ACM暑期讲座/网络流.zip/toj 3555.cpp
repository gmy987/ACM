#pragma comment(linker, "/STACK:102400000,102400000")
#include<iostream>
#include<cstdio>
#include<memory.h>
#include<string>
#include<cmath>
#include<cctype>
#include<algorithm>
#include<queue>
#include<set>
#include<map>
#include<stack>
#include<vector>
#include<functional>
#define sqr(x) ((x)*(x))
#define ll long long
#define ii pair<int,int>
#define mp make_pair
#define ms(x,y) memset(x,y,sizeof(x))
#define rep(x,y,z) for (int x=y;x<z;x++)
#define drep(x,y,z) for (int x=y;x>=z;x--)
#define all(x) x.begin(),x.end()
#define X first
#define Y second
using namespace std;
const int size=410,esize=210*210,mod=1000000007,inf=0x3f3f3f3f;
const ll llmod=4294967296ll,llinf=0x3f3f3f3f3f3f3f3fll;
const double pi=acos(-1.0),eps=1e-7;
int month[2][13]={0,31,28,31,30,31,30,31,31,30,31,30,31,
                  0,31,29,31,30,31,30,31,31,30,31,30,31};
int nex[2][8]={-1,0,1,0,-1,1,1,-1,0,1,0,-1,1,1,-1,-1};
template<class T> inline void inc(T &a,T b){a=(a+b)%mod;}
template<class T> inline T modu(T a){return (a%mod+mod)%mod;}
template<class T> inline void crl(T* l,T *r,int step){T tmp=*l;for (T* i=l;i<r;i+=step)*i=*(i+step);*(r-1)=tmp;}
template<class T> inline void crr(T* l,T *r,int step){T tmp=*(r-1);for (T* i=r-1;i>l;i-=step)*i=*(i-step);*l=tmp;}
bool inline dbeq(double a,double b){return fabs(a-b)<eps;}
template<class T> inline void cmin(T& a,T b){a=min(a,b);}
template<class T> inline void cmax(T& a,T b){a=max(a,b);}
/***********************************************************/
struct edge
{
	int a,b,next,f;
}e[size*size*8];//sizeӦ�ô��ڲ���ĵ���֮��
int cnt,v[size];
void init()
{
	cnt=0,memset(v,-1,sizeof(v));
}
void add (int a,int b,int f)//��ÿ������߽���
{
	e[cnt].a=a;
	e[cnt].b=b;
	e[cnt].f=f;
	e[cnt].next=v[a];
	v[a]=cnt++;
	e[cnt].b=a;
	e[cnt].a=b;
	e[cnt].f=0;
	e[cnt].next=v[b];
	v[b]=cnt++;
}
int dis[size],q[size];
int bfs(int s,int t)  
{  
    int i,x,a,tail=0,head=0;  
    memset(dis,0,sizeof(dis));  
    dis[s]=1;  
    q[tail++]=s;  
    while(head<tail)  
    {  
        x=q[head++];          
        for(i=v[x];i!=-1;i=e[i].next)  
            if(e[i].f&&dis[a=e[i].b]==0)  
            {  
                dis[a]=dis[x]+1;  
                if(a==t)  
                    return 1;  
                q[tail++]=a;  
            }  
    }  
    return 0;  
}  
int dfs(int s,int t,int limit)  
{  
    if(s==t)  
        return limit;  
    int i,a,tmp,cost=0;  
    for(i=v[s];i!=-1;i=e[i].next)  
        if(e[i].f&&dis[s]==dis[a=e[i].b]-1)  
        { 
            tmp=dfs(a,t,min(limit-cost,e[i].f));  
            if(tmp>0)  
            {  
                e[i].f-=tmp;  
                e[i^1].f+=tmp;  
                cost+=tmp;  
                if(limit==cost)  
                    break;  
            }  
            else dis[a]=-1;  
        }  
    return cost;  
}  
int Dinic(int s,int t)  
{  
    int ans=0;  
    while(bfs(s,t))  
        ans+=dfs(s,t,inf);  
    return ans;  
}
struct node
{
	int a,b,d;
}eg[esize];
int de[size];
bool mark[size];
char str[size];
//��ʼ��parent[i]=i;
int parent[size];
int find (int x)
{
	if (parent[x]==x)
		return x;
	return parent[x]=find(parent[x]);
}
void un (int a,int b)
{
	parent[find(a)]=find(b);
}
int main ()
{
	int ca,n,m,k,s,t,a,ans,sum;
	scanf("%d",&ca);
	rep(cas,1,ca+1)
	{
		scanf("%d",&m);
		rep(i,0,26)
			parent[i]=i;
		ms(de,0);
		ms(mark,0);
		rep(i,0,m)
		{
			scanf("%s%d",str,&eg[i].d);
			eg[i].a=str[0]-'a',eg[i].b=str[strlen(str)-1]-'a';
			de[eg[i].b]--,de[eg[i].a]++;
			mark[eg[i].a]=mark[eg[i].b]=1;
			un(eg[i].a,eg[i].b);
		}
		int fa=-1,cc=0;
		rep(i,0,26)
			if (mark[i]&&find(i)!=fa)
				fa=find(i),cc++;
		if (cc>=2)
		{
			printf("Case %d: Poor boy\n",cas);
			continue;
		}
		init();
		s=30,t=31,sum=0;
		int cnt=0;
		rep(i,0,26)
			if (mark[i])
			{
				if (de[i]%2!=0)
					cnt++;
				if (de[i]>0)
					add(s,i,de[i]/2),sum+=de[i]/2;
				else
					add(i,t,de[i]/-2);

			}
		printf("Case %d: ",cas);
		if (cnt>2)
			puts("Poor boy!");
		else
		{
			rep(i,0,m)
				if (eg[i].d==1)
					add(eg[i].a,eg[i].b,1);
			int tmp=Dinic(s,t);
			if (tmp==sum)
				puts("Well done!");
			else
				puts("Poor boy!");
		}
	}
	return 0;
}
/*
111
4
ab 1
ba 1
cd 1
dc 1
*/