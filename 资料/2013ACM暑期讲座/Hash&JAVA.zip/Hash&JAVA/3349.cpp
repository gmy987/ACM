#include<iostream>
#include<cstring>
using namespace std;
int hash[1000000][6];
const long long int mr=999997;
//1 2 3 4 5 6 1 2 3 4 5 6
//6 5 4 3 2 1 6 5 4 3 2 1
bool same(int s[],int t[])
{
    int i,j,k;
    bool ch;
    for(i=0; i<6; i++)
    {
        ch=true;
        for(j=0; j<6; j++)
        {
            if(s[j]!=t[(j+i)%6])
            {
                ch=false;
                break;
            }
        }
        if(ch)
            return true;
    }
    for(i=0; i<6; i++)
    {
        ch=true;
        for(j=0,k=5; j<6; j++,k--)
        {
            if(s[j]!=t[(k+i)%6])
            {
                ch=false;
                break;
            }
        }
        if(ch)
            return true;
    }
    return false;
}
void insert(int a[])
{
    int i,key,sum=0;
    long long int x;
    for(i=0; i<6; i++)
    {
        x=a[i];
        x=x*x%mr;
        sum=(sum+x)%mr;
    }
    key=sum,i=1;
    while(hash[key][0]!=-1)
    {
        key=(sum+i)%mr;
        i++;
    }
    for(i=0; i<6; i++)
    {
        hash[key][i]=a[i];
    }
}
bool find(int a[])
{
    int i,key,sum=0;
    long long int x;
    for(i=0; i<6; i++)
    {
        x=a[i];
        x=x*x%mr;
        sum=(sum+x)%mr;
    }
    key=sum,i=1;
    while(hash[key][0]!=-1&&!same(hash[key],a))
    {
        key=(sum+i)%mr;
        i++;
    }
    if(hash[key][0]==-1)
        return false;
    else
        return true;
}
int main()
{
    int num,i,j,a[10],co=0;
    bool ok=false;
    memset(hash,-1,sizeof(hash));
    scanf("%d",&num);
    while(num--)
    {
        co++;
        for(i=0; i<6; i++)
            scanf("%d",a+i);
        if(!ok)
        {
            ok=find(a);
            insert(a);
        }
        else
            break;

    }
    if(ok)
    {
        printf("Twin snowflakes found.\n");
    }
    else
    {
        printf("No two snowflakes are alike.\n");
    }
}
