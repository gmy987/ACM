import java.util.*;
import java.math.*;
public class Main {
	public static void main(String arg[])
	{
		Scanner cin=new Scanner(System.in);
		int []a=new int[5];
		int i,j,i1,i2,i3,ans=0;
		while(cin.hasNext())
		{
			HashMap<Integer,Integer> H=new HashMap<Integer,Integer>();
			for(i=0;i<5;i++)
				a[i]=cin.nextInt();
			ans=0;
			for(i1=-50;i1<=50;i1++)
			{
				if(i1==0)
					continue;
				for(i2=-50;i2<=50;i2++)
				{
					if(i2==0)
						continue;
					for(i3=-50;i3<=50;i3++)
					{
						if(i3==0)
							continue;
						i=i1*i1*i1*a[0]+i2*i2*i2*a[1]+i3*i3*i3*a[2];
						if(H.containsKey(i))
						{
							j=1+H.get(i);
							H.put(i, j);
						}
						else
						{
							H.put(i, 1);
						}
					}
				}
			}
			for(i=-50;i<=50;i++)
			{
				if(i==0)
					continue;
				for(j=-50;j<=50;j++)
				{
					if(j==0)
						continue;
					int t=i*i*i*a[3]+j*j*j*a[4];
					if(H.containsKey(-t))
					{
						ans=ans+H.get(-t);
					}
				}
			}
			System.out.println(ans);
		}
		
	}
}