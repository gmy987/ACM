/*给定一个序列，如下操作:
 *(1) INSERT pos tot c1,c2... 在pos位置后插入tot个数c1,c2...
 *(2) DELETE pos tot          从第pos个数开始删除连续tot个数
 *(3) MAKE-SAME pos tot c     将pos个数字开始的连续tot个数改为c 
 *(4) REVERSE pos tot         从pos位置将tot个数字翻转
 *(5) GET-SUM pos tot         从pos位置开始连续tot个数的和
 *(6) MAX-SUM                 当前数列的最大子段和
 */
#include <cstdio>
#include <cstring>
#include <iostream>
#define max(a,b)  ((a)>(b)?(a):(b))
#define INF 0x1f1f1f1f
#define MAXN 500100
#define debug() printf("fuck!\n");

using namespace std;

typedef int EleType;

int ary[MAXN];
typedef struct Node{
	Node *pre, *ch[2];
	int key, size;
	int rev, same;
	int sum, ml, mr, mc;
	//sum表示以当前结点为根的树的和
	//ml 左边连续的最大值   mr 右边连续的最大值   mc 该点作为根时连续的最大值
	inline int L_size(){ return ch[0]?ch[0]->size:0; }
	inline int R_size(){ return ch[1]?ch[1]->size:0; }
	inline int L_sum() { return ch[0]?ch[0]->sum:0;  }
	inline int R_sum() { return ch[1]?ch[1]->sum:0;  }
	inline int L_ml()  { return ch[0]?ch[0]->ml:0;   }
	inline int R_ml()  { return ch[1]?ch[1]->ml:0;   }
	inline int L_mr()  { return ch[0]?ch[0]->mr:0;   }
	inline int R_mr()  { return ch[1]?ch[1]->mr:0;   }
	inline int L_mc()  { return ch[0]?ch[0]->mc:0;   }
	inline int R_mc()  { return ch[1]?ch[1]->mc:0;   }
}Node ,*LNode;

int a[MAXN];

class Splay{
public:
	LNode null, root, S[MAXN];
	Node  data[MAXN];
	int cnt, top;

	LNode get(int key){                  //手动管理内存
		LNode p;
		if(top) p = S[--top];
		else    p = &data[cnt++];
		p->key = p->sum = p->ml = p->mr = p->mc = key;
		p->size = 1; p->rev = p->same = 0;
		p->ch[0] = p->ch[1] = p->pre = null;
		return p;
	}

	void init(int l,int n){
		cnt = top = 0;
		null = get(-INF);
		null->size = null->sum = 0;
		root = get(-INF);
		root->ch[1] = get(INF);
		root->sum = root->ch[1]->sum = 0;
		root->ch[1]->pre = root;
		update(root);
		///以下为题目的数列建树
		LNode troot = build(l, n);
    		root->ch[1]->ch[0] = troot;
    		troot->pre = root->ch[1];
   		update(root->ch[1]);
    		update(root);
    		splay(root->ch[1], null);
		
	}
	void update(LNode p){
		push_down(p);
		push_down(p->ch[0]);
		push_down(p->ch[1]);
		p->size = p->L_size() + p->R_size() + 1;
		p->sum = p->L_sum() + p->R_sum() + p->key;
		////
		p->ml = max(p->L_ml(),p->L_sum() + p->key + max(p->R_ml(),0));
		p->mr = max(p->R_mr(),p->R_sum() + p->key + max(p->L_mr(),0));
		////
		p->mc = max(p->L_mc(),p->R_mc());
		p->mc = max(p->mc, max(p->L_mr() + p->R_ml(),0) + p->key);
		p->mc = max(p->mc,max(p->L_mr(),p->R_ml()) + p->key);
	}
	void push_down(LNode x){
		if(x == null) return;
		if(x->rev){
			swap(x->ch[0],x->ch[1]);
			if(x->ch[0] != null) x->ch[0]->rev ^= 1;
			if(x->ch[1] != null) x->ch[1]->rev ^= 1;
			swap(x->ml,x->mr);
			x->rev ^= 1;
		}
		if(x->same){
			x->sum = x->size * x->key;
			x->mc = x->ml = x->mr = max(x->key,x->sum);
			if(x->ch[0] != null){
				x->ch[0]->key = x->key;
				x->ch[0]->same = 1;
			}
			if(x->ch[1] != null){
				x->ch[1]->key = x->key;
				x->ch[1]->same = 1;
			}
			x->same = 0;
		}
	}
	void rotate(LNode x,int c){
		// c = 0 左旋  c = 1 右旋
		LNode y = x->pre;
		push_down(y); push_down(x);
		y->ch[!c] = x->ch[c];
		if(x->ch[c] != null){
			x->ch[c]->pre = y;
		}
		x->pre = y->pre;
		if(y->pre != null){
			if(y->pre->ch[0] == y){
				y->pre->ch[0] = x;
			}else{
				y->pre->ch[1] = x;
			}
		}
		x->ch[c] = y;
		y->pre = x;
		if(y == root) root = x;
	
		update(y);
	}
	void splay(LNode x,LNode f){
	//把x旋转为f的儿子,若f为null则把x旋转到根结点位置
		push_down(x);
		while(x->pre != f){
			LNode y = x->pre, z = y->pre;
			if(x->pre->pre == f){  // zig 操作
				rotate(x,x->pre->ch[0] == x);
			}else{
				if(z->ch[0] == y){
					if(y->ch[0] == x){   // zig-zig
						rotate(y,1);
						rotate(x,1);
					}else{               // zig-zag
						rotate(x,0);
						rotate(x,1);
					}
				}else{
					if(y->ch[1] == x){   // zag-zag
						rotate(y,0);
						rotate(x,0);
					}else{               // zag-zig
						rotate(x,1);
						rotate(x,0);
					}
				}
			}
		}
		update(x);
	}
	void select(int k,LNode f){
	//找到第k个元素，并把该元素旋转成为f的儿子
		int tmp;	
		LNode t = root;
		while(true){
			push_down(t);
			tmp = t->ch[0]->size;
			if(tmp + 1 == k) break;
			if(k <= tmp) t = t->ch[0];
			else{
				k -= (tmp + 1);
				t = t->ch[1];
			}
		}
		splay(t,f);
	}
	void insert(int pos,int val){
		//在pos前插入一个结点
		LNode tmp = get(val);
		select(pos - 1,null);
		select(pos, root);
		root->ch[1]->ch[0] = tmp;
		tmp->pre = root->ch[1];
		splay(root->ch[1],null);
	}
	void insert(int pos,LNode p){      //在pos后接一棵子树,即一个区间
		select(pos,null);
		select(pos + 1,root);
		root->ch[1]->ch[0] = p;
		p->pre = root->ch[1];
		update(root->ch[1]);
		update(root);
		splay(p,null);
	}
	void Delete_root(){
		LNode old_root = root;
		root = root->ch[1];
		root->pre = null;
		select(1,null);
		root->ch[0] = old_root->ch[0];
		root->ch[0]->pre = root;
		update(root);
		S[++top] = old_root;
	}    
	void recycle(LNode p){
		if(p->ch[0] != null) recycle(p->ch[0]);
		if(p->ch[1] != null) recycle(p->ch[1]);
		S[top++] = p;
	}
	LNode Delete(int l,int r){
		//删除[l,r]区间
		//将该 l-1 splay到根，r+1 splay到根的右结点，砍掉根右结点的左子树，
		select(l - 1,null);
		select(r + 1,root);
		if(root->ch[1]->ch[0] != null){
			recycle(root->ch[1]->ch[0]);
			root->ch[1]->ch[0] = null;
		}
		update(root->ch[1]);
		update(root);
		splay(root->ch[1],null);
		//return p;
		
	}
	void split(int a,int b,int c){        //将区间[a,b]砍下来接到第c个元素后边
		LNode p = Delete(a,b);	
		insert(c,p);
	}
	void replace(int x,int y){
		//把第x位置的元素替换为y
		select(x,null);
		root->key = y;
		update(root);
	}
	void replace(int l,int r,int c){      //将区间[l,r]的所有元素置换为c
		select(l - 1,null);
		select(r + 1,root);
		root->ch[1]->ch[0]->key = c;
		root->ch[1]->ch[0]->same = 1;
		splay(root->ch[1]->ch[0],null);
	}
	void reverse(int l,int r){
		//将区间[l,r]反转
		select(l - 1,null);
		select(r + 1,root);
		if(root->ch[1]->ch[0] != null) root->ch[1]->ch[0]->rev ^= 1;
		splay(root->ch[1]->ch[0],null);
	}
	LNode build(int l,int r){
		if(l > r) return null;
		int m = (l + r) >> 1;
		LNode p = get(a[m]);
		p->ch[0] = build(l, m - 1);
		if(p->ch[0] != null)
			p->ch[0]->pre = p;
		p->ch[1] = build(m + 1, r);
		if(p->ch[1] != null)
			p->ch[1]->pre = p;

		update(p);
		return p;
	}
	void inorder(LNode x){
		if(x == null) return;
		push_down(x);
		inorder(x->ch[0]);
		//if(x->key != INF && x->key != -INF){
			printf("%d ",x->key);
			if(x->ch[0] == null) printf("left = null ");
			else printf("left = %d ",x->ch[0]->key);
			if(x->ch[1] == null) printf("right = null\n");
			else printf("right = %d\n",x->ch[1]->key);
		//}
		inorder(x->ch[1]);
	}

};

Splay sp;

int main()
{
	int n, m, i, x, y;
	int pos, tot, c;
	int N = 0;
    char ch[15];
	scanf("%d%d", &n,&m);
    for(int i = 1; i <= n; ++i)
        scanf("%d", &a[i]);
    sp.init(1,n);	 	
    while(m--){
		scanf("%s",ch);
		if(ch[0] == 'I'){                        //Insert pos tot
			scanf("%d%d",&pos,&tot);
			for(int i = 1;i <= tot; ++i)
				scanf("%d",&a[i]);
			LNode p = sp.build(1,tot);
			sp.insert(++pos, p);
		}else if(ch[0] == 'D'){                 // Delete pos tot
			scanf("%d%d",&pos,&tot);
			sp.Delete(pos + 1,pos + tot);
		}else if(ch[0] == 'M' && ch[2] == 'K'){
			scanf("%d%d%d",&pos,&tot,&c);
			sp.replace(pos + 1,pos + tot, c);
		}else if(ch[0] == 'R'){
			scanf("%d%d",&pos,&tot);
			sp.reverse(pos + 1,pos + tot);
		}else if(ch[0] == 'G'){
			scanf("%d%d",&pos,&tot);
			sp.select(pos,sp.null);
			sp.select(pos + tot + 1,sp.root);
			int ans = sp.root->ch[1]->ch[0]->sum;
			printf("%d\n",ans);
		}else{
			sp.select(1, sp.null);
			sp.select(sp.root->size, sp.root);
			int ans = sp.root->ch[1]->ch[0]->mc;
			printf("%d\n",ans);
		}
	}
    return 0;		
}
