#include <cstdio> 
#include <cstring> 
#include <vector>
#include <algorithm>
#define MAXN 30010
#define INF 0x1f1f1f1f

using namespace std;

struct Edge{
	int v, w, next;
	Edge(){}
	Edge(int _v,int _w, int _next):v(_v),w(_w),next(_next){}
}edge[MAXN*2];
int size;
int hash[MAXN];
bool is_heavy[MAXN];

struct SegmentTree;
void insert(SegmentTree *ltree, int pos, int num);


struct Node{
	int val, deep, heavy, father, father_cost;
	int head;
	SegmentTree* owner;
}node[MAXN];

struct Segment{
	int max;
	Segment *lc, *rc;
}seg[MAXN*2], *se;

struct SegmentTree{
	Node *start;
	int size;
	Segment *root;
}tree[MAXN], *tr;

void init(int n){
	memset(node, 0, sizeof(Node)*(n+1));
	memset(is_heavy, false,sizeof(bool)*(n+1));
	for(int i = 1;i <= n; ++i){
		node[i].head = -1;
		node[i].father_cost = -INF;
	}
	se = seg;
	tr = tree;
	size = 0;
}
void add_edge(int u,int v, int w){
	edge[size] = Edge(v, w, node[u].head);
	node[u].head = size ++;
}
char ch[7];
void DFS(int u, int f){
	node[u].father = f;
	node[u].deep = 1;
	node[u].heavy = u;
	for(int i = node[u].head;i != -1;i = edge[i].next){
		if(edge[i].v == f) continue;
		DFS(edge[i].v, u);
		if(node[edge[i].v].deep + 1 > node[u].deep){
			node[u].deep = node[edge[i].v].deep + 1;
			node[u].heavy = edge[i].v;
		}
	}
}
Segment *newSegment(){
	se->lc = se->rc = NULL;
	se->max = -INF;
	return se ++;
}
void dfs(int u, int f){
	if(node[u].owner == NULL){
		node[u].owner = tr;
		tr->start = node + u;
		tr->size = node[u].deep - 1;
		tr->root = newSegment();
		tr ++;
	}
	node[node[u].heavy].owner = node[u].owner;
	for(int i = node[u].head;i != -1;i = edge[i].next){
		if(edge[i].v == f){
			node[u].father_cost = edge[i].w;
			continue;
		}
		if(edge[i].v == node[u].heavy){
			insert(node[u].owner, node[u].deep - 1, edge[i].w);
			hash[i/2] = u;
			is_heavy[i/2] = true;
		}else   hash[i/2] = edge[i].v;
		dfs(edge[i].v, u);
	}
}

void insert(Segment *l, int fr, int to, int pos,int num){
	if(fr == to){
		l->max = num;
		return ;
	}
	if(l->lc == NULL){
		l->lc = newSegment();
		l->rc = newSegment();
	}
	int mid = (fr + to)/2;
	if(pos <= mid) insert(l->lc, fr, mid, pos, num);
	else insert(l->rc, mid + 1, to, pos, num);
	l->max = max(l->lc->max, l->rc->max);
}

void insert(SegmentTree *ltree, int pos, int num){
	insert(ltree->root, 1, ltree->size, pos, num);
}
int Seg_max(Segment *l, int left, int right, int fr, int to){
	if(left == fr && right == to) return l->max;
	int mid = (left + right) >> 1;
	if(to <= mid) return Seg_max(l->lc, left, mid, fr, to);
	if(fr > mid) return Seg_max(l->rc, mid + 1, right, fr, to);
	return max(Seg_max(l->lc, left, mid, fr, mid), Seg_max(l->rc, mid + 1, right, mid + 1, to));
}
int get_max(int a, int b){
	int ma = -INF;
	int fr, to;
	while(node[a].owner != node[b].owner){
		//printf("a = %d b = %d ma = %d\n",a,b,ma);
		if(node[a].owner->start->deep > node[b].owner->start->deep) swap(a, b);
		fr = node[a].deep + 1;
		to = node[a].owner->start->deep;
		if(node[a].owner->size == 0) ma = max(ma, node[a].father_cost);
		else if(fr <= to)
			ma = max(ma, Seg_max(node[a].owner->root, 1, node[a].owner->size, fr, to));
		ma = max(ma, node[a].owner->start->father_cost);
		a = node[a].owner->start->father;
		//printf("after a = %d b = %d ma = %d\n",a,b,ma);
	}
	if(node[a].owner == node[b].owner){
		if(a == b) return ma;
		fr = node[a].deep;
		to = node[b].deep;
		if(fr > to) swap(fr, to);
		ma = max(ma, Seg_max(node[a].owner->root, 1, node[a].owner->size, fr + 1, to));
	}else{
		if(node[a].deep > node[b].deep) ma = max(ma, node[b].father_cost);
		else ma = max(ma, node[a].father_cost);
	}
	return ma;
}
void debug(){
	printf("max = %d\n",tree[0].root->max);
	if(tree[0].root->lc != NULL) printf("left = %d\n",tree[0].root->lc->max);
	if(tree[0].root->rc != NULL) printf("right = %d\n",tree[0].root->rc->max);
}
int main()
{
	int cas, n, u, v, w;
	scanf("%d",&cas);
	while(cas --){
		scanf("%d",&n);
		init(n);
		for(int i = 1;i < n; ++i){
			scanf("%d%d%d",&u,&v,&w);
			add_edge(u, v, w);
			add_edge(v, u, w);
		}
		DFS(1, 0);
		dfs(1, 0);
		for(int i = 1;i <= n; ++i){
			node[i].deep -= 1;
		}
		//for(int i = 0;i < n; ++i)
		//	if(is_heavy[i]) printf("%d is heavy\n",i+1);
		while(scanf("%s",ch)){
			if(ch[0] == 'D') break;
			switch(ch[0]){
				case 'C':scanf("%d%d",&u,&v);
					 u --;
					 if(is_heavy[u]) 
						 insert(node[hash[u]].owner, node[hash[u]].deep,v);
					 else node[hash[u]].father_cost = v;
					 break;
				case 'Q':scanf("%d%d",&u,&v);
					 int tmp = 0;
					 if(u != v) tmp = get_max(u, v);
					 printf("%d\n",tmp);
					 break;
			}
		}
	}

}

