 #include <cstdio>
#include <cstring>
#include <iostream>
#define max(a,b)  ((a)>(b)?(a):(b))
#define INF 0x1f1f1f1f
#define MAXN 10100
#define debug() printf("fuck!\n");

using namespace std;

typedef int EleType;

int ary[MAXN];
typedef struct Node{
	Node *pre, *ch[2];
	int key, size;
	int sum, ml, mr, mc;
	//sum��ʾ�Ե�ǰ���Ϊ�������ĺ�
	//ml ������������ֵ   mr �ұ����������ֵ   mc �õ���Ϊ��ʱ���������ֵ
	inline int L_size(){ return ch[0]?ch[0]->size:0; }
	inline int R_size(){ return ch[1]?ch[1]->size:0; }
	inline int L_sum() { return ch[0]?ch[0]->sum:0;  }
	inline int R_sum() { return ch[1]?ch[1]->sum:0;  }
	inline int L_ml()  { return ch[0]?ch[0]->ml:0;   }
	inline int R_ml()  { return ch[1]?ch[1]->ml:0;   }
	inline int L_mr()  { return ch[0]?ch[0]->mr:0;   }
	inline int R_mr()  { return ch[1]?ch[1]->mr:0;   }
	inline int L_mc()  { return ch[0]?ch[0]->mc:0;   }
	inline int R_mc()  { return ch[1]?ch[1]->mc:0;   }
}Node ,*LNode;

class Splay{
public:
	LNode null, root, S[MAXN];
	Node  data[MAXN];
	int cnt, top;

	LNode get(int key){                  //�ֶ������ڴ�
		LNode p;
		if(top) p = S[top--];
		else    p = &data[cnt++];
		p->key = p->sum = p->ml = p->mr = p->mc = key;
		p->size = 1;
		p->ch[0] = p->ch[1] = p->pre = null;
		return p;
	}

	void init(){
		cnt = top = 0;
		null = get(-INF);
		null->sum = null->size = 0;
		root = get(-INF);
		root->sum = 0;
		root->ch[1] = get(INF);
		root->ch[1]->sum = 0;
		root->ch[1]->pre = root;

		update(root);
	}
	
	void update(LNode p){
		p->size = p->L_size() + p->R_size() + 1;
		p->sum = p->L_sum() + p->R_sum() + p->key;
		////
		p->ml = max(p->L_ml(),p->L_sum() + p->key + max(p->R_ml(),0));
		p->mr = max(p->R_mr(),p->R_sum() + p->key + max(p->L_mr(),0));
		////
		p->mc = max(p->L_mc(),p->R_mc());
		p->mc = max(p->mc, max(p->L_mr() + p->R_ml(),0) + p->key);
		p->mc = max(p->mc,max(p->L_mr(),p->R_ml()) + p->key);
	}

	void rotate(LNode x,int c){
		// c = 0 ����  c = 1 ����
		LNode y = x->pre;
		y->ch[!c] = x->ch[c];
		if(x->ch[c] != null){
			x->ch[c]->pre = y;
		}
		x->pre = y->pre;
		if(y->pre != null){
			if(y->pre->ch[0] == y){
				y->pre->ch[0] = x;
			}else{
				y->pre->ch[1] = x;
			}
		}
		x->ch[c] = y;
		y->pre = x;
		if(y == root) root = x;
	
		update(y);
	}
	void splay(LNode x,LNode f){
	//��x��תΪf�Ķ���,��fΪnull���x��ת�������λ��
		while(x->pre != f){
			if(x->pre->pre == f){  // zig ����
				rotate(x,x->pre->ch[0] == x);
			}else{
				LNode y = x->pre;
				LNode z = y->pre;
				if(z->ch[0] == y){
					if(y->ch[0] == x){   // zig-zig
						rotate(y,1);
						rotate(x,1);
					}else{               // zig-zag
						rotate(x,0);
						rotate(x,1);
					}
				}else{
					if(y->ch[1] == x){   // zag-zag
						rotate(y,0);
						rotate(x,0);
					}else{               // zag-zig
						rotate(x,1);
						rotate(x,0);
					}
				}
			}
		}
		update(x);
	}
	void select(int k,LNode f){
	//�ҵ���k��Ԫ�أ����Ѹ�Ԫ����ת��Ϊf�Ķ���
		int tmp;	
		LNode t = root;
		while(true){
			tmp = t->ch[0]->size;
			if(tmp + 1 == k) break;
			if(k <= tmp) t = t->ch[0];
			else{
				k -= (tmp + 1);
				t = t->ch[1];
			}
		}
		splay(t,f);
	}
	void replace(int x,int y){
		select(x,null);
		root->key = y;
		update(root);	
	}
	LNode build(int l,int r){
		if(l > r) return null;
		int m = (l + r) >> 1;
		LNode p = get(ary[m]);
		p->ch[0] = build(l, m - 1);
		if(p->ch[0] != null)
			p->ch[0]->pre = p;
		p->ch[1] = build(m + 1, r);
		if(p->ch[1] != null)
			p->ch[1]->pre = p;

		update(p);
		return p;
	}

};

Splay sp;
int sum[MAXN];
int main()
{
	int T, n, m, t, i, x1, y1, x2, y2;
    	scanf("%d",&T);
    	while(T--){
 		sp.init();
		scanf("%d", &n);
		sum[0] = 0;
    		for(int i = 1; i <= n; ++i){
       		 	scanf("%d", &ary[i]);
    			sum[i] = sum[i-1] + ary[i];
    		} 
    		Node *troot = sp.build(1, n);
    		sp.root->ch[1]->ch[0] = troot;
    		troot->pre = sp.root->ch[1];
   		sp.update(sp.root->ch[1]);
    		sp.update(sp.root);
    		sp.splay(sp.root->ch[1], sp.null);
		scanf("%d",&m);
		while(m--){
			scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
			if(x2 >= y1){
				int mid = sum[x2-1] - sum[y1];
				sp.select(x1,sp.null);
				sp.select(y1 + 2,sp.root);
				int s = sp.root->ch[1]->ch[0]->mr;
				sp.select(x2,sp.null);
				sp.select(y2 + 2,sp.root);
				int t = sp.root->ch[1]->ch[0]->ml;
				printf("%d\n",s + mid + t);
			}	
			else{ 	
				/// x1--s---x2---y------y2
				int ret1 = 0, ret2 = 0, ret3 = 0;
				sp.select(x1,sp.null);
				sp.select(x2 + 2,sp.root);
				ret1 += sp.root->ch[1]->ch[0]->mr;
				sp.select(x2,sp.null);
				sp.select(y2 + 2,sp.root);
				ret1 += sp.root->ch[1]->ch[0]->ml;
				ret1 -= ary[x2];
				///
				sp.select(x2,sp.null);
				sp.select(y1 + 2,sp.root);
				ret2 = sp.root->ch[1]->ch[0]->mc;
				///
				ret3 += sp.root->ch[1]->ch[0]->mr;
				sp.select(y1,sp.null);
				sp.select(y2 + 2,sp.root);
				ret3 += sp.root->ch[1]->ch[0]->ml;
				ret3 -= ary[y1];
				
				int ans = max(ret1, max(ret2, ret3));
				printf("%d\n",ans);
			}
		}
    		
    	}		
	return 0;
}

