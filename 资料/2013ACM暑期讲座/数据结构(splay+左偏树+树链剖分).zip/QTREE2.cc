#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#define MAXN 10010

using namespace std;
typedef pair<int,int> Pair;

struct Query{
	int type;
	int a, b, k, ans, ret;
}q[MAXN*10];
struct Edge{
	int v, w, next;
	Edge(){}
	Edge(int _v,int _w,int _next):v(_v),w(_w),next(_next){}
}edge[MAXN*2];
int head[MAXN], size, n;
int dist[MAXN], cnt, DIST[MAXN], ans[MAXN];
int father[MAXN], stk[MAXN], top;
bool vis[MAXN];
vector<Pair > lca[MAXN], Kth[MAXN];

void init(){
	for(int i = 1;i <= n; ++i){
		lca[i].clear();
		Kth[i].clear();
		father[i] = i;
	}
	memset(vis, false, sizeof(bool)*(n+1));
	memset(head, -1, sizeof(int)*(n+1));
	size = cnt = top = 0;
}
inline void add_edge(int u, int v, int w){
	edge[size] = Edge(v, w, head[u]);
	head[u] = size ++;
}
int find(int x){
	if(father[x] == x) return x;
	return father[x] = find(father[x]);
}
void Tarjan(int u){
	vis[u] = true;
	for(int i = head[u];i != -1;i = edge[i].next){
		int v = edge[i].v;
		int w = edge[i].w;
		if(!vis[v]){
			dist[v] = dist[u] + w;
			DIST[v] = DIST[u] + 1;
			Tarjan(v);
			father[v] = u;
		}
	}
	for(int i = 0;i < (int)lca[u].size(); ++i){
		int v = lca[u][i].first;
		if(vis[v]) q[lca[u][i].second].ans = find(v);
	}
}
void DFS(int u){
	vis[u] = true;
	stk[top++] = u;
	if(Kth[u].size() != 0){
		for(int i = 0;i < (int)Kth[u].size(); ++i){
			q[Kth[u][i].second].ret = stk[top-Kth[u][i].first];
		}
	}

	for(int i = head[u];i != -1;i = edge[i].next){
		int v = edge[i].v;
		if(!vis[v]) DFS(v);
	}
	top --;
}
int main()
{
	int cas;
	int u, v, w;
	scanf("%d",&cas);
	while(cas --){
		scanf("%d",&n);
		init();
		for(int i = 1;i < n; ++i){
			scanf("%d%d%d",&u,&v,&w);
			add_edge(u, v, w);
			add_edge(v, u, w);
		}
		char ch[7];
		while(scanf("%s",ch)){
			if(ch[1] == 'O') break;
			if(ch[1] == 'I'){
				q[cnt].type = 0;
				scanf("%d%d",&u,&v);
				q[cnt].a = u;
				q[cnt++].b = v;
				lca[u].push_back(Pair(v,cnt-1));
				lca[v].push_back(Pair(u,cnt-1));
			}else{
				q[cnt].type = 1;
				scanf("%d%d%d",&u,&v,&w);
				q[cnt].a = u;
				q[cnt].b = v;
				q[cnt++].k = w;
				lca[u].push_back(Pair(v,cnt-1));
				lca[v].push_back(Pair(u,cnt-1));
			}
		}
		dist[1] = DIST[1] = 0;
		Tarjan(1);
		for(int i = 0;i < cnt; ++i){
			if(q[i].type == 0){
				q[i].ret = dist[q[i].a] + dist[q[i].b] - 2*dist[q[i].ans];
			}else{
				int tmp = DIST[q[i].a] - DIST[q[i].ans] + 1;
				int t = DIST[q[i].b] - DIST[q[i].ans] + 1;
				//printf("tmp = %d t = %d\n",tmp,t);
				if(tmp >= q[i].k){
					Kth[q[i].a].push_back(Pair(q[i].k,i));
				}
					
				else {
					Kth[q[i].b].push_back(Pair(t - (q[i].k - tmp),i));
				}
			}
		}
		//printf("fucking %d %d\n",q[0].ans,q[1].ans);
		memset(vis, false, sizeof(bool)*(n+1));
		DFS(1);
		for(int i = 0;i < cnt; ++i){
			printf("%d\n",q[i].ret);
		}
	}	
}


