#include <cstdio> 
#include <cstring> 
#include <vector>
#include <algorithm>
#define MAXN 120010
#define INF 0x1f1f1f1f

using namespace std;

struct Edge{
	int v, next;
	Edge(){}
	Edge(int _v, int _next):v(_v),next(_next){}
}edge[MAXN*2];
int size;
int one;

struct SegmentTree;
void insert(SegmentTree *ltree, int pos, int num);


struct Node{
	int val, deep, heavy, father;
	int head;
	SegmentTree* owner;
}node[MAXN];

struct Segment{
	int col, id;
	int ans_deep, ans_id;
	Segment *lc, *rc;
}seg[MAXN*2], *se;

struct SegmentTree{
	Node *start;
	int size;
	Segment *root;
}tree[MAXN], *tr;

void init(int n){
	memset(node, 0, sizeof(Node)*(n+1));
	for(int i = 1;i <= n; ++i){
		node[i].head = -1;
	}
	se = seg;
	tr = tree;
	size = 0;
}
void add_edge(int u,int v){
	edge[size] = Edge(v, node[u].head);
	node[u].head = size ++;
}
void DFS(int u, int f){
	node[u].father = f;
	node[u].deep = 1;
	node[u].heavy = u;
	for(int i = node[u].head;i != -1;i = edge[i].next){
		if(edge[i].v == f) continue;
		DFS(edge[i].v, u);
		if(node[edge[i].v].deep + 1 > node[u].deep){
			node[u].deep = node[edge[i].v].deep + 1;
			node[u].heavy = edge[i].v;
		}
	}
}
Segment *newSegment(){
	se->lc = se->rc = NULL;
	se->col = 1;
	se->id = se->ans_deep = se->id = -1;
	return se ++;
}
void dfs(int u, int f){
	if(node[u].owner == NULL){
		node[u].owner = tr;
		tr->start = node + u;
		tr->size = node[u].deep;
		tr->root = newSegment();
		tr ++;
	}
	node[node[u].heavy].owner = node[u].owner;
	for(int i = node[u].head;i != -1;i = edge[i].next){
		if(edge[i].v == f) continue;
		dfs(edge[i].v, u);
	}
}

void insert(Segment *l, int fr, int to, int pos,int id){
	if(fr == to){
		l->col ^= 1;
		l->id = id;
		if(l->col){
		       	l->ans_id = id;
			l->ans_deep = node[id].deep;
		}else{
			l->ans_id = l->ans_deep = -1;
		}
		return ;
	}
	if(l->lc == NULL){
		l->lc = newSegment();
		l->rc = newSegment();
	}
	int mid = (fr + to)/2;
	if(pos <= mid) insert(l->lc, fr, mid, pos, id);
	else insert(l->rc, mid + 1, to, pos, id);
	if(l->rc->ans_id != -1){
		l->ans_id = l->rc->ans_id;
		l->ans_deep = l->rc->ans_deep;
	}else{
		l->ans_id = l->lc->ans_id;
		l->ans_deep = l->lc->ans_deep;
	}
}

void insert(SegmentTree *ltree, int pos, int id){
	insert(ltree->root, 1, ltree->size, pos, id);
}

pair<int,int> query(Segment *l, int left, int right, int fr, int to){
	if(left == fr && right == to) return make_pair(l->ans_deep, l->ans_id);
	int mid = (left + right) >> 1;
	if(to <= mid) return query(l->lc, left, mid, fr, to);
	if(fr > mid) return query(l->rc, mid + 1,right, fr, to);
	else return max(query(l->lc, left,mid, fr, mid), query(l->rc, mid + 1, right, mid + 1, to));
}
int query(int u){
	int ans = -1, id = -1;
	int fr, to;
	while(node[u].owner != node[1].owner){
		fr = node[u].deep;
		to = node[u].owner->start->deep;
		//printf("u = %d fr = %d to = %d\n",u,fr,to);
		pair<int,int> tmp = query(node[u].owner->root, 1, node[u].owner->size, fr, to);
		//printf("tmp = (%d,%d)\n",tmp.first,tmp.second);
		if(tmp.first > ans) {
			ans = tmp.first;
			id = tmp.second;
		}
		u = node[u].owner->start->father;
	}
	pair<int,int> tmp = query(node[1].owner->root, 1, node[1].owner->size, node[u].deep, node[u].owner->start->deep);
	if(ans < tmp.first) id = tmp.second;
	return id;
}
int main()
{
	int cas, n, u, v, w, Q;
	scanf("%d%d",&n,&Q);
	init(n);
	one = 0;
	for(int i = 1;i < n; ++i){
		scanf("%d%d",&u,&v);
		add_edge(u, v);
		add_edge(v, u);
	}
	DFS(1, 0);
	dfs(1, 0);
	for(int i = 1;i <= n; ++i)
		insert(node[i].owner, node[i].deep, i);
	for(int i = 1;i <= Q; ++i){
		scanf("%d%d",&u,&v);
		if(u == 0){
		       	insert(node[v].owner, node[v].deep, v);
			if(v == 1) one ^= 1;
		}else{
			if(v == 1 && one == 1) printf("1\n");       
			else printf("%d\n",query(v));
		}
	}
}


