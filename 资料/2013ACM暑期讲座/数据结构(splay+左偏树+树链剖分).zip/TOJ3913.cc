import java.util.*;
import java.io.IOException;
import java.io.InputStream;

class Segment{
    Segment(int l,int r){
        this.l = l;
        this.r = r;
        this.add = 0L;
        if(l == r){
            this.sum = Main.a[l];
            return;
        }
        this.lc = new Segment(l,(l+r)/2);
        this.rc = new Segment((l+r)/2 + 1,r);
        this.sum = this.lc.sum + this.rc.sum;
    }
    Segment Update(int l,int r,long add){
        if(this.l > r || this.r < l) return this;
        Segment tmp = new Segment(0,0);
        tmp.l = this.l;
        tmp.r = this.r;
        if(l <= this.l && r >= this.r){
            tmp.lc = this.lc;
            tmp.rc = this.rc;
            tmp.add = this.add + add;
            tmp.sum = this.sum + (tmp.r - tmp.l + 1)*add;
            return tmp;
        }
        tmp.lc = lc.Update(this.l, this.r, this.add).Update(l, r, add);
        tmp.rc = rc.Update(this.l, this.r, this.add).Update(l, r, add);
        tmp.add = 0L;
        tmp.sum = tmp.lc.sum + tmp.rc.sum;
        return tmp;
    }
    long Query(int l,int r,long add){
        if(this.l > r || this.r < l) return 0L;
        if(l <= this.l && r >= this.r) return this.sum + (this.r - this.l + 1)*add;
        add += this.add;
        return lc.Query(l, r, add) + rc.Query(l, r, add);
    }
    int l, r;
    long add, sum;
    Segment lc, rc;
}
public class Main {

    static int[] a = new int[1000100];
    public static void main(String[] args) {
        SpeedReader in = new SpeedReader(System.in);
        //Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int m = in.nextInt();
        Segment[] roots = new Segment[m + 1];
        for(int i = 1;i <= n; ++i) a[i] = in.nextInt();
        roots[0] = new Segment(1, n);
        int tm = 0;
        for(int i = 0;i < m; ++i){
            String str = in.next();
            switch(str.charAt(0)){
                case 'Q':
                    System.out.println(roots[tm].Query(in.nextInt(),in.nextInt(),0));
                    break;
                case 'C':
                    roots[tm+1] = roots[tm].Update(in.nextInt(),in.nextInt(),in.nextInt());
                    tm ++;
                    break;
                case 'H':
                    int l = in.nextInt(), r = in.nextInt(), t = in.nextInt();
                    System.out.println(roots[t].Query(l, r, 0));
                    break;
                case 'B':
                    tm = in.nextInt();
                    break;
            }
        }
    }
}
class SpeedReader {
    final InputStream in;
    SpeedReader(InputStream in) {
        this.in = in;
    }
    String next() {
        String x = "";
        int ch=-1;
        do
            try {
                ch = in.read();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        while(Character.isWhitespace(ch));
        while(!Character.isWhitespace(ch)) {
            x += (char) ch;
            try {
                ch = in.read();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return x;
    }
    int nextInt() {
        return Integer.parseInt(next());
    }    
}  
