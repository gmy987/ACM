#include <cstdio>
#include <cstring>
#include <ctime>
#include <cstdlib>

using namespace std;

typedef int EleType;
typedef struct Node{
	EleType key;   //结点信息
	int cnt, size, fix;  //关键字出现次数，以该结点为根的子树权值和，修正值
	Node *left, *right;
	inline int L_size(){ return left?left->size:0; }
	inline int R_size(){ return right?right->size:0; }
}Node, *LNode;

LNode root;

void L_Rotate(LNode &p){
	LNode rc = p->right;
	p->right = rc->left;
	rc->left = p;
	p = rc;
	rc = p->left;
	rc->size = rc->L_size() + rc->R_size() + rc->cnt;
	p->size = p->L_size() + p->R_size() + p->cnt;
}
void R_Rotate(LNode &p){
	LNode lc = p->left;
	p->left = lc->right;
	lc->right = p;
	p = lc;
	lc = p->right;
	lc->size = lc->L_size() + lc->R_size() + lc->cnt;
	p->size = p->L_size() + p->R_size() + p->cnt;
}
void Insert(LNode &T,EleType key){
	if(!T){
		T = new Node;
		T->left = T->right = NULL;
		T->key = key; T->fix = rand();
		T->cnt = T->size = 1;                        //新插入的结点cnt 和size 都为1
	}else if(T->key == key) { T->cnt ++; T->size ++; }   //注意size也要+1
	else if(T->key > key){
		T->size ++;
		Insert(T->left,key);
		if(T->left->fix < T->fix) R_Rotate(T);
	}else{
		T->size ++;
		Insert(T->right,key);
		if(T->right->fix < T->fix)L_Rotate(T);
	}
}

inline void Erase(LNode &T){                        // Erase()是真正删除这个结点，递归删除
	if(!T->left) {
		LNode q = T;
		T = T->right;
		free(q);
	}else if(!T->right) {
		LNode q = T;
		T = T->left; 	
		free(q);
	}else{
		if(T->left->fix > T->right->fix){
			L_Rotate(T);
			Erase(T->left);
			
		}else{
			R_Rotate(T);
			Erase(T->right);
		}
	}
}

void Delete(LNode &T,EleType key){           //需要先保证存在key值
	T->size --;
	if(T->key == key){
		T->cnt --;                  //删除的话注意是否该结点的关键字出现多次
		if(!T->left || !T->right){
			LNode q = T;
			if(T->cnt == 0){
				if(!T->left) T = T->right;
				else         T = T->left;
				free(q);
			}
		}else{
			if(T->cnt == 0) Erase(T);
		}
	}
	else if(T->key > key) Delete(T->left,key);
	else   Delete(T->right,key);
}

inline EleType Find_Kth(LNode T,EleType k){          //找第k大的元素
	if(T->size < k)
		return -1;            //无解
	if(T->L_size() >= k) return Find_Kth(T->left,k);
	if(T->L_size() + T->cnt < k) 
		return Find_Kth(T->right,k - (T->L_size()) - (T->cnt));
	return T->key;
}

inline int Rank(LNode T,EleType key){                       //key是第几大元素
	if(!T)  return 0;
	else if(key < T->key) return Rank(T->left,key);
	else   return  (T->L_size() + T->cnt + Rank(T->right,key));
}

inline bool Search(LNode T,EleType key){
	if(!T) return false;
	if(T->key == key) return true;
	else if(T->key > key) return Search(T->left,key);
	else return Search(T->right,key);
}

void InOrder(LNode t){
	if(!t) return;
	InOrder(t->left);
	printf("%d ",t->key);
	InOrder(t->right);
}
int main()
{
	//freopen("/home/minjie/TOJ/in.txt","r",stdin);
	root = NULL;
	srand(time(NULL));
	int n, tmp;
	clock_t start, end;
	start = clock();
	scanf("%d",&n);
	for(tmp = 1;tmp <= n; tmp += 2){
		//scanf("%d",&tmp);
		Insert(root,tmp);
	}
	end = clock();
	//Delete(root,3);
	printf("kth = %d\n",Find_Kth(root,4));
	InOrder(root);
	//Insert(root,2);Insert(root,2);
	
	printf("Treap = %.4lf\n",(double)(end-start)/CLOCKS_PER_SEC);
	
}
